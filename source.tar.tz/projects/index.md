---
title: circle flow
id: '102'
tags: []
categories:
  - - uncategorized
comments: false
date: 2016-01-31 10:43:18
---

circle flow是一个以太网流量分析设备的项目，已在[github开源](https://github.com/circleflow/code/wiki)。 基于以太网交换芯片，提供以太网流量的生成和分析功能。 需要强调的是，它具备全端口线速流量的处理能力，和基于linux+网卡的软件解决方案完全不同。 同时它也是低成本的，利用已有的以太网交换机，单纯软件开发升级就可实现。 更多项目内容请阅读这篇[介绍文档](https://raw.github.com/circleflow/code/master/_docs/introduction%20of%20circle%20flow.pdf)， 代码相关的技术细节都在这篇[文档](https://raw.github.com/circleflow/code/master/_docs/architecture%20and%20intergration.pdf)。 希望circle flow能带给你一些启发或价值。