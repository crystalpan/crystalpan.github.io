---
title: callback的进化
tags: []
id: '213'
categories:
  - - tech
date: 2016-08-26 10:58:45
---

###### *Don’t ask, I’ll call you back.*

这句来自好莱坞选角导演的老话是callback的写照，callback相比polling更高效和及时，只要可能，我们就会选择callback方式。
<!-- more -->

## 函数指针

在C语言场景下，函数指针是唯一的选择，client先把回调函数地址注册给回调者(caller)，后者在合适的时候调用该函数。 

```c++
typedef void (*CALL_BACK) (int itf, int link, int speed);

int eth_itf_notify_register(CALL_BACK cb);
```

 caller需要对注册的函数指针进行保存，如果全局仅支持一个回调函数，那么一个全局变量就可以解决问题。当允许注册多个回调函数时，需要使用数据结构（数组，链表）来存储。 

进一步的当存在回调规则时，比如仅特定对象（某个网络接口），这个数据结构会更复杂一些，它需要支持规则查找。  

```c++
int eth_itf_notify_register (int itf, event_callback cb);
```

函数指针注册时可以额外带一个参数（cookie），并在回调时传递回来，适用于回调函数内部的处理需要上下文信息，可以定义多个cookie。最极端的例子是定时器的回调函数，其参数全都是cookie，这样只需要一个类型转换，任何函数都可以被封装成timer\_callback类型。

```c++
 typedef void (*timer_callback) (void *cookie_0, void *cookie_1, void *cookie_2);
int timer_register (int delay_ms, timer_callback cb, void *cookie_0, void *cookie_1, void *cookie_2);
```

 某些场景还需要支持回调注销，比如某个定时器还未到，但已经不再需要了，这时候可以通过注销来避免调用。 

```c++
int timer_unregister(timer_callback cb)
```

 总结下来，一个完整的callback机制会涉及这几个功能： 数据结构（存储和查找函数指针以及cookie），上下文信息传递，生命周期管理 

接下来我们切换到C++的世界，看看上述这几个功能点的实现可以有怎样的变化。

* * *

## 继承模式

通过继承机制，上下文信息和生命周期可以有另一番实现方式，主要通过client继承并实现caller定义的类来实现。 

```c++
struct ETH_ITF_NOTIFY {

    ETH_ITF_NOTIFY(int itf);
    virtual ~ETH_ITF_NOTIFY();
     
    virtual void operator () (int itf, int link, int speed) = 0;

private:
    int itf;
};
```

其中的函数操作符重载函数为纯虚函数，由client来实现相当于回调函数部分的功能，实际上不必非得是重载函数操作符，只要是虚函数就行。构造函数相当于register函数，析构函数相当于unregister。 client部分的代码可以是这样， 

```c++
struct CLIENT_NOTIFY : public ETH_ITF_NOTIFY {
    void operator () (int itf, int link, int speed)
    {
        //do something as client
    }

    CLIENT_NOTIFY(int itf, int context_v)
    : ETH_ITF_NOTIFY(itf),
      context_val(context_v)
    { }

private:
    int context_val;
};

void demo()
{
    CLIENT_NOTIFY *notify_manual = new CLIENT_NOTIFY(1,1);

    {
        CLIENT_NOTIFY notify_scope(2,0);
     
        //stuff ...
     
        //callback invalidated automatically before exit the scope
    }
     
    delete notify_manual;   //manually invalidate callback

}
```

可以看到CLIENT\_NOTIFY对象的生命周期决定了回调的有效期，常见的方式是把它作为其他类的成员对象，自动跟随其它需要该回调服务的对象的生命周期，当需要该回调服务的对象结束时，回调自然也就不再需要了。
上下文也变得更灵活，通过定义CLIENT\_NOTIFY的成员变量，我们可以支持任意数量和类型的上下文，在构造时传入这些上下文。重点是，上下文变得与caller无关了。 顺便演示一下如何基于STL的multimap来实现数据结构部分的实现，multimap的key就是回调规则。 

```c++
#include <map>

typedef std::multimap<int, ETH_ITF_NOTIFY *> DB_NOTIFY;
static  DB_NOTIFY db_notify;

ETH_ITF_NOTIFY::ETH_ITF_NOTIFY(int _itf)
:itf(_itf)
{
    db_notify.insert(std::make_pair(itf, this));
}

ETH_ITF_NOTIFY::~ETH_ITF_NOTIFY()
{
    DB_NOTIFY::iterator it_first = db_notify.lower_bound(itf);
    DB_NOTIFY::iterator it_end   = db_notify.upper_bound(itf);

    for(DB_NOTIFY::iterator it=it_first; it!=it_end; it++) {
        if(it->second == this) {
            db_notify.erase(it);
            return;
        }
    }
}

void dispatch_notify(int itf, int link, int speed)
{
    DB_NOTIFY::iterator it_first = db_notify.lower_bound(itf);
    DB_NOTIFY::iterator it_end   = db_notify.upper_bound(itf);

    for(DB_NOTIFY::iterator it=it_first; it!=it_end; it++) {
        (*it->second)(itf, link, speed);
    }
}
```

无可否认，继承是一种强耦合，如果有其他选择，继承可能就不会是首选。

* * *

## 函数对象模式

C++11引入的functional库极大地便利了C++编程，这一点在回调上体现得非常充分。 
下面的代码展示了如何通过function对象来实现回调注册。

```c++
#include <functional>
using namespace std::placeholders;

typedef std::function<void (int itf, int link, int speed)> CALL_BACK_F;
void eth_itf_notify_bind(CALL_BACK_F cb);

void client_notify(int itf, int link, int speed)
{
    //...
}

void client_notify_cookie(int itf, int link, int speed, void *cookie)
{
    //...
}

struct CLIENT_IMPL {
    void eth_itf_notify(int itf, int link, int speed);
};

void demo_2()
{
    //no cookie
    eth_itf_notify_bind(client_notify);

    //with cookie
    int context;
    eth_itf_notify_bind(std::bind(client_notify_cookie,_1,_2,_3,&context));
     
    //class member function
    CLIENT_IMPL client;
    eth_itf_notify_bind(std::bind(&CLIENT_IMPL::eth_itf_notify, &client, _1, _2, _3));

}
```

function对象的神奇之处在于可以封装任何可调用的接口，包括函数，类成员函数，以及带有operator ()成员的函数对象，上面的代码展示了前两种情况。 
这里的类对象不再局限于某个专用回调接口类（ETH\_ITF\_NOTIFY）的子类，而是任意对象（只要能bind），这一点令代码大为简化。例如演示代码，直接将某个功能实现类的对象和成员函数bind为回调函数对象，这意味着回调函数对象有着大量的上下文变量可以使用，相比之下，继承模式则需要重复定义和显式传递上下文。
此外，上下文的传递也可以通过bind来绑定额外的参数。需要注意的是，任何bind进去的参数都是以值的方式存储在function对象里，也就是copy了一份，对于引用类型，需要显式地用reference\_wrapper 来封装，或者直接传递指针。

和继承模式不同，我们无法通过function的构造析构来实现回调的注册和注销，演示代码展示了通过专用的接口来注册，那么如何注销呢？ 是不是可以参考C方式提供一个unregister接口，可惜function对象并不支持相互比较，而unregister的内部实现必须通过比较来查找。
常见的方式是通过智能指针shared\_ptr 和 weak\_ptr。 

```c++
#include <memory>

using std::shared_ptr;
using std::weak_ptr;

void eth_itf_notify_attach(int itf, weak_ptr<CALL_BACK_F> wp_cb);

void demo_3()
{
    //no cookie
    shared_ptr<CALL_BACK_F> sp(new CALL_BACK_F(client_notify));
    eth_itf_notify_attach(1, sp);

    //with cookie
    {
        int context;
        shared_ptr<CALL_BACK_F> sp2(new CALL_BACK_F);
        *sp2 = std::bind(client_notify_cookie,_1,_2,_3,&context);
        eth_itf_notify_attach(2, sp2);
    }   //callback function client_notify_cookie turns into invalid
     
    //class member function
    CLIENT_IMPL client;
    shared_ptr<CALL_BACK_F> sp3(new CALL_BACK_F);
    *sp3 = std::bind(&CLIENT_IMPL::eth_itf_notify, &client, _1, _2, _3);
    eth_itf_notify_attach(3, sp3);

}
```

和继承模式类似，shared\_ptr对象的生命周期决定了回调对象的生命周期。 另外，在dispatch中需要判断weak\_ptr是否有效（expired()），清理无效对象的工作可以在attach时进行。

```c++
typedef std::multimap<int, weak_ptr<CALL_BACK_F> > DB_FUNC;
static  DB_FUNC db_func;

static bool is_cb_expired(const DB_FUNC::value_type &val_pair)
{
    return val_pair.second.expired();
}

#include <algorithm>
using std::find_if;

void eth_itf_notify_attach(int itf, weak_ptr<CALL_BACK_F> wp_cb)
{
    db_func.insert(std::make_pair(itf, wp_cb));

    //purge invalid cb
    DB_FUNC::iterator it;
    while( db_func.end() !=
            (it=find_if(db_func.begin(), db_func.end(), is_cb_expired))) {
        db_func.erase(it);
    }
}

void dispatch_func(int itf, int link, int speed)
{
    DB_FUNC::iterator it_first = db_func.lower_bound(itf);
    DB_FUNC::iterator it_end   = db_func.upper_bound(itf);

    for(DB_FUNC::iterator it=it_first; it!=it_end; it++) {
        weak_ptr<CALL_BACK_F> wp=it->second;
     
        if(!wp.expired())
            (*wp.lock())(itf, link, speed);
    }
}
```



* * *

###### *Ring, ring, ring ...* 

###### *Hi, we want you!*