---
title: 错误处理的简洁之道 (二) C++
tags:
  - C
  - exception
  - RAII
  - scope guard
  - 异常
  - 编程
  - 错误处理
id: '38'
categories:
  - - tech
date: 2016-01-17 18:02:06
---

我真正发现C++的妙处是在与它相识十年以后。
在这十年里，我一直从事嵌入式系统偏底层模块的开发，在这个领域，一般认为C语言是不二的选择（虽然仔细推敲起来其理由并不太成立）。
我也同样这么深信不疑，直到十年以后的一天，STL 容器和算法的简便性打动了我，我开始尝试在一个新模块中使用C++，然后，一个广阔的新天地出现了... 

在这个新天地中，错误处理借助C++的若干个特性，实现了真正的简洁。
<!-- more -->

* * *

## exception（异常）

对于异常的普遍误解有：影响性能，增加代码体积，以及使用起来并不方便和简洁。
我相信这些认识可能是在浅尝辄止后下的结论，我们会在后面再来仔细检视这些理解误区。 

异常的主要作用在于提供了一个不同于return语句的返回手段，通过throw可以直接返回到临近的try/catch位置，它不仅仅是指令跳转和堆栈的回滚，更重要的是，堆栈回滚时栈内的对象会被析构。 
so，只要栈内对象的析构函数保证了资源的释放，那么异常跳转就可以保证资源的回滚操作。

* * *

## RAII（资源获取即初始化）

在构造函数中申请资源，在析构函数中释放资源。 
如果构造失败，抛出异常。

```c++
class FOO{
public:
  FOO()
  :bar()
  {
    buf = new char[BUF_SIZE];
    if(0==buf) throw ERROR(__FUNCTION__,__LINE__);
  }

  ~FOO()
  {
    delete buf;
  }
private:
  BAR bar;
  char *buf;
};
```

 如果内存分配失败，就抛出异常，堆栈回滚，请注意，此时并不调用~FOO()，但是会析构已经构造成功的成员变量对象bar，假定BAR同样具备RAII特性，那么bar会在其析构时释放相关资源，于是异常引起的堆栈回滚会确保所有资源一个不拉地被释放。至于应该在哪里catch这些异常，后面会讨论。

实际上new也可以在分配失败时抛出类型为std::bad\_alloc的异常，取决于链接的stdlib是否支持异常，因此这段代码可以进一步省略掉对new返回值的判断。 

接下来，如果增加一个同样需要进行new操作的buf\_2成员变量，在buf\_2内存分配失败时该怎么处理buf的回滚呢？ 
答案是，把一切资源都变成RAII对象，对于内存资源，可以使用C++标准库提供的智能指针。

```c++
class FOO{
public:
  FOO()
  :bar(),
   buf_1(new char[BUF_SIZE]),
   buf_2(new char[BUF_SIZE]) 
  {  }

private:
  BAR bar;
  unique_ptr<char> buf_1;
  unique_ptr<char> buf_2;
};
```

C++11引入的unique\_ptr智能指针对象会在其析构函数中调用delete来释放内存，如果是C++98环境可以使用auto\_ptr代替unique\_ptr，或者使用boost库。智能指针是现代C++编程的重要组成部分。 

如果buf\_1的new操作失败，bar会被析构，如果buf\_2的new失败了，buf\_1和bar都会被析构。 另外，由于FOO的所有成员变量都是RAII的，因此其析构函数可以省略。 

现在看起来，只要确保资源类对象是RAII的，且构造失败时会抛出异常，我们就**再也不需要**检查资源是否分配失败。

如果回滚操作不是资源的释放，而是一些事务性的回滚，比如这样：

```c++
void do_steps(char *dir, char *file, char *data)
{
  create_dir(dir);
  create_file(file);
  modify_file(data);
}
```

比如当create\_file函数抛出异常时，我们希望回滚create\_dir函数所作的操作：删除新建的目录。
是的，我们的确可以把三个函数都封装成RAII对象，但有所变化的是，在do\_steps成功返回时这些对象也会被析构，而在这种情况下我们并不希望回滚操作。
有两个办法来避免，让这些RAII对象一直存在，或者在do\_steps成功返回前通知他们不需要真正析构。
对于事务性的调用，我们并不希望每次调用就要创建若干个新的对象并一直持有它，否则反复调用的结果就是产生大量的对象将内存耗尽，这和资源类的调用恰恰相反，后者正是希望持有这些资源对象。 
看来只有第二个办法才合适，但它并不简洁，我们为此要将接口封装为RAII的class，这些class还要额外提供接口来设置是否在析构时啥都不做。 

除了RAII,还需要一副解药。

* * *

## scope guard

scope guard相当于仅有析构部分的RAII。

```c++
class SCOPE_GUARD
{
public:
  SCOPE_GUARD(std::function<void()> on_exception)
  : on_exp(on_exception)
  { }

  ~SCOPE_GUARD()
  {
    if(std::uncaught_exception())  on_exp();
  }

private:
    std::function<void()> on_exp;
};
```

它的析构函数仅在处于异常抛出而尚未被catch的情况下，执行特定的处理。
因此do\_steps现在可以这样实现 

```cc
void do_steps(char *dir, char *file, char *data)
{
  create_dir(dir);
  SCOPE_GUARD rollback_dir([&] { delete_dir(dir); });

  create_file(file);
  SCOPE_GUARD rollback_file([&] { delete_file(file); });

  modify_file(data);
}
```

 我们还可以进一步用宏来增强可读性

```cc
#define LINENAME_CAT(name, line) name##line
#define LINENAME(name, line) LINENAME_CAT(name, line)
#define ON_ERROR(rollback) SCOPE_GUARD LINENAME(scope_guard, __LINE__)([&]{ rollback })

void do_steps(char *dir, char *file, char *data)
{
  create_dir(dir);
  ON_ERROR( delete_dir(dir); );

  create_file(file);
  ON_ERROR( delete_file(file); );

  modify_file(data);
}
```

 宏隐藏了变量名以及lambda表达式，因此阅读时的注意力就可以集中到滚操作的核心内容。 
上述的scope guard机制使用了C++11中的lambda和function，C++98环境下的实现会大不一样，具体可以看[这里](http://www.drdobbs.com/cpp/generic-change-the-way-you-write-excepti/184403758)，不过最终经宏封装后的使用方式大体一致。

因此，只要保证代码是exception safe（即出现异常时，堆栈回滚能自动释放资源或回滚操作），并且我们调用的函数会在出错时抛出异常，我们就**不再需要**检查是否出错。
仔细想想上面这句话，它应该挑战了我们多年的实际编程经验，那些铺天盖地对返回值做检查的代码现在终于可以消失了。

当然，如果被调用的函数不会抛出异常呢，比如os的API，这种情况下检查还是无法避免，不过宏可以给我们一些帮助。 

```cc
#define ENSURE(expression) \
    if(!(expression)) throw ERROR(__FUNCTION__, __LINE__, #expression);

void do_steps(char *dir, char *file, char *data)
{
  ENSURE(OK==create_dir(dir));
  ON_ERROR( delete_dir(dir); );

  ENSURE(OK==create_file(file));
  ON_ERROR( delete_file(file); );

  ENSURE(OK==modify_file(data));
}
```

注意，rollback中的函数调用不应该再检查是否出错，因为在异常中再抛出异常可能导致terminate。 

最后，我们再来看前面提出的几个问题。 
_**在哪里catch异常**_ 
以我有限的实践经验，it depends ： 
如果在一个legacy的系统中，有模块支持异常，也有模块不支持异常，那么使用异常的模块的API就需要定义两套。一套接口定义为exception free，即不会抛出异常，通过返回值指示错误，另外一套API则允许抛出异常。 
在exception free的这套API的实现里去调用会抛出异常的API接口，同时catch异常并转为返回值。 
这种情况下catch位于模块的API边界。 
如果是在一个彻底的使用exception来传递错误的系统里，那么只需要在整个系统的IO边界catch即可。

**_异常的性能问题，以及引起代码体积膨胀_** 
性能下降基本可以忽略，代码体积增加大概10%左右。 
其实只要考虑到那些同时可以消除的极其巨量的返回值检查代码，这就已经pay back了，更不用提消除重复和提高可读性带来的收益。 

**_异常使用起来并不方便_** 
oh, really ? 

或许客观条件局限，我们可能无法在已有的系统中使能异常机制，但基于RAII+scope\_guard+return的方式，还是大有帮助的，而这只需要在现有方式上做一点点改变。

```cc
class SCOPE_GUARD
{
public:
  SCOPE_GUARD(std::function<void()> on_error, bool &ref_dismiss)
  : on_err(on_error),
    dismiss(ref_dismiss)
  { }

  ~SCOPE_GUARD()
  {
    if(!dismiss)  on_err();
  }

private:
    std::function<void()> on_err;
    bool &dismiss;
};

#define ON_ERROR(rollback) SCOPE_GUARD LINENAME(scope_guard, __LINE__)([&]{ rollback }, dismiss)
#define ENSURE(expression) if(!(expression)) return ERR;

int do_steps(char *dir, char *file, char *data)
{
  bool dismiss = false;

  ENSURE(OK == create_dir(dir));
  ON_ERROR( delete_dir(dir); );

  ENSURE(OK == create_file(file));
  ON_ERROR( delete_file(file); );

  ENSURE(OK == modify_file(data));

  dismiss = true;

  return OK;
}
```

这一点点的改变包括，增加了控制scope\_guard是否执行的机制，然后将ENSURE从throw改为return。 

至此，“简洁之道”已经展示完全了，我们实现了避免检查返回值，和简洁的回滚操作（RAII不需要显式回滚，而事务性回滚紧挨着事务性操作且没有重复）。
它是你寻找的“完美之道”吗 ？

* * *

真正经过大量编程实践的工程师可能明白，出错时回滚操作还不一定就完事了。很多时候，错误是因为代码存在bug，我们需要把它找出来才能万事大吉，而出错时的上下文信息可以提供重要线索。 如何尽可能多地记录上下文，而且要足够简洁，下篇文章将会展示一些探索。

* * *

## 参考

C++11（及现代C++风格）和快速迭代式开发 
[http://mindhacks.cn/2012/08/27/modern-cpp-practices/](http://mindhacks.cn/2012/08/27/modern-cpp-practices/) 
Generic: Change the Way You Write Exception-Safe Code — Forever 
[http://www.drdobbs.com/cpp/generic-change-the-way-you-write-excepti/184403758](http://www.drdobbs.com/cpp/generic-change-the-way-you-write-excepti/184403758)