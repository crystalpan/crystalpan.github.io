---
title: pimpl的妙处
tags:
  - C
  - pimpl
  - 二进制兼容性
  - 实现
  - 接口
  - 继承
id: '130'
categories:
  - - tech
date: 2016-04-01 16:32:28
---

C++的数据封装留了一尾巴夹在门缝处，它让外部世界可以通过这条门缝窥见内部细节。
<!-- more -->
 例如定义一个外部接口类：

```c++
class FOO {
public:
    void do_something();
     
private:
    SECRECT data;
};
```

 其中的SECRECT类型虽然作为private数据，但也必须外部可见，否则编译不过。通常掩人耳目的做法是把它放在另外一个头文件中。

```c++
#include "internal_def.h"

class FOO {
...
    SECRECT data;
};
```

 internal\_def.h仍然是外部可见的，这样的方式实际上只是将接口无关的信息挪到别处，便于阅读而已。 
除了暴露内部细节，这条尾巴还传递了编译依赖。如果SECRECT结构发生改动，那么所有使用FOO的客户代码都必须重新编译。特别的，这对要求二进制兼容性的动态链接库而言是不可接受的。

* * *

## pimpl (pointer to implementation)

pimpl就是为了解决这两个问题，并且它同时还带来了其他诸多好处。 基于pimpl，上述代码可以这样写：

```c++
class FOO {
public:
    FOO();
    ~FOO();

    void do_something();

private:
    struct IMPL;
    IMPL *pimpl;
};
```

 内部数据结构被一个指针所替代，指向一个数据结构或类对象。由于指针长度固定，因此编译器不需要看到IMPL的具体定义就可以为pimpl分配空间。于是IMPL这个结构的定义可以放在FOO的实现文件中，这样真正的数据隐藏就实现了：

```c++
struct FOO::IMPL {
    void do_something();
};

FOO::FOO()
:pimpl (0)
{
    pimpl = new IMPL();
}

FOO::~FOO()
{
    delete pimpl;
}

void FOO::do_something()
{
    pimpl->do_something();
}
```

pimpl机制是将原先存放在栈上的数据结构挪到了堆上，只留了一个指针在栈上。这带来了一个好处，就是栈对象的大小可以是固定的。由于非虚成员函数的数量与对象大小没有关系，因此只要对象大小不变，非虚接口的变化并不需要重新编译客户代码，这是实现二进制兼容性的关键之一。 
pimp带来的第二个好处是对单键的透明支持。我们可以将一个全局唯一IMPL对象地址直接赋值给pimpl，比如一个static的IMPL对象的地址，这就做到了单键，并且对客户而言是透明的。 
同理，对于swap操作，pimpl也极其高效。 

此外，pimpl模式下一般存在两级调用：外部类接口再转调内部实现类接口，这固然是多了一层开销，但同时也可以把一些职责放在外部接口的实现中，比如，参数检查，异常拦截，互斥处理，trace输出等等，起到分离职责的作用，让内部类的职责更加聚焦。

## 接口和实现的分离

实际上pimpl带来的妙处远远不止这些，它还深刻的影响了继承的实现方式。 传统的继承方式需要用虚函数来实现多态：

```c++
class BASE {
public:
    virtual void do_something();
    virtual ~BASE();
};

class DERIVED : public BASE {
public:
void do_something();
    ~DERIVED();
};
```

 然而使用pimpl机制后并不需要多态： 

```c++
class BASE {
public:
    BASE();
    ~BASE();
    void do_something();

    struct IMPL;    //be public, to be inherited

protected:
    BASE(IMPL *);   //only for derived class

    IMPL *pimpl;

};

class DERIVED : public BASE {
public:
    DERIVED();
};
```

关键在于IMPL的实现，它使用了继承和多态。

```c++
struct BASE::IMPL {
    virtual void do_something();
    virtual ~IMPL();
};

struct DERIVED_IMPL : public BASE::IMPL {
    void do_something();
    ~DERIVED_IMPL();
};
```

对应的外部类的构造函数实现如下，注意其中的BASE有个protected的构造函数，用于子类的构造。而当BASE作为纯接口类时，就无需定义public的构造函数了。 

```c++
BASE::BASE()
:pimpl(new IMPL())
{
}

BASE::BASE(IMPL *p)
:pimpl(p)
{
}

BASE::~BASE()
{
    delete pimpl;
}

DERIVED::DERIVED()
:BASE(new DERIVED_IMPL())
{
}
```

于是BASE::do\_something不再需要定义为虚函数，但它仍旧实现了多态。

```c++
void BASE::do_something()
{
    pimpl->do_something();
}
```

简单来说，pimpl机制下，存在内外两条继承关系树：外部接口类的继承树和内部IMPL类的继承树。表面看起来好像存在重复，其实这分离了接口继承和功能继承。
举个例子，假设do\_something实际可以分解为do\_step\_1和do\_step\_2，而step\_1是稳定的，多态只存在于step\_2，于是功能继承会变成这样: 

```c++
struct BASE::IMPL {
    void do_step_1();
    virtual void do_step_2();
...
};

struct DERIVED_IMPL : public BASE::IMPL {
    void do_step_2();
    ...
};

void BASE::do_something()
{
    pimpl->do_step_1();
    pimpl->do_step_2();
}
```

试想一下，如果是外部接口do\_something为虚函数，这就要求所有的子类都需要实现该接口，并且需要遵守一个编程契约，即首先调用do\_step\_1，然后剩余部分做不同处理。这个契约是脆弱的，而且当调用规则变得复杂时，比如有若干个step时，代码的重复度也相应增加。 
问题的根本在于内部实现函数的粒度和外部接口函数的粒度是存在差异的，把两者绑在一起就会带来麻烦。编程范式NVI（no virtual interface）提倡的就是这个分离原则，而在pimpl机制下，这个分离实现得非常干净。 

再回到二进制兼容性，由于外部接口类不再需要虚函数，甚至连析构函数都不需要定义为虚，这就彻底避免了对象大小的变动。

## 动态对象优化

IMPL内部对象的分配是基于动态内存，这对于大对象有着良好的堆栈空间优化效果，换句话说，对于大对象，我们不必担心堆栈空间是否足够，这让客户代码减少了一层依赖。但对于小对象则带来一些性能浪费，如有必要可以采取一种灵活的预分配机制：

```cc
class BAR {
public:
    BAR();
    ~BAR();
protected:
    struct IMPL;
    IMPL *pimpl;
    char data[16];
};

BAR::BAR()
{
    assert(sizeof(IMPL) <= sizeof(data));
    pimpl = reinterpret_cast<IMPL*>(data);
    new(pimpl)IMPL();
}

BAR::~BAR()
{
    pimpl->~IMPL();
}
```

pimpl指向data，无需使用动态内存，随着开发的持续，当IMPL的空间尺寸超过预分配的大小后，再把pimpl改为动态内存方式。如此既可兼顾小尺寸对象的性能，又可优化大尺寸对象的内存。 当然，基于动态内存的内部对象分配也意味着用户代码无法掌控对象的存储位置，比如用户希望通过某种特殊内存池来分配，而实际上IMPL对象总是固定地来自于动态内存池。如有必要，可以通过传入allocator的方式（构造参数或模板参数）来自定义内部对象的分配。

* * *

pimpl的应用范围一般仅限于外部接口类，它同时隐藏了内部数据和内部方法，因此让外部接口类的声明非常简洁，基本上看不到与外部接口无关的内容。这是它一开始让人喜欢的原因，随着深入使用，这种看似多套一层的机制不断展现出其他特有的优势，或许一段时间后，我又可以再补上几条。 

现在，那扇门彻底关上了。