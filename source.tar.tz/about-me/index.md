---
title: about me
id: '94'
tags: []
categories:
  - - uncategorized
comments: false
date: 2016-01-31 09:57:26
---

通信设备软件工程师一枚，埋头编码十余年。 终于醒悟，即使积累不多，只言片语，亦可分享交流一番。 还有还有，[联系方式](mailto:circleflow@yeah.net)不能少～